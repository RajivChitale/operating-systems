#include "types.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int param = 0;
    if(argc!=2){printf(2, "One argument is required (one of n,i,a)\n"); exit();} 
    char mode = argv[1][0];
    if(mode == 'n' || mode == '0') {param = 0;}
    else if(mode == 'i' || mode =='1') {param = 1;}
    else if(mode == 'a' || mode == '2') {param = 2;}
    else {printf(2, "Arguments accepted are n (none), i (ignore write), a (all)\n");}
    trail(param);
    exit();
}
